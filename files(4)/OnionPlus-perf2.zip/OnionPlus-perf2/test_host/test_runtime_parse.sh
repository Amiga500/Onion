old_parse() {
    cmd=$1; rompath=""; launch_script=""; romext=""; romcfgpath=""
    if echo "$cmd" | grep -q "retroarch/cores" || echo "$cmd" | grep -q "/../../Roms/" || echo "$cmd" | grep -q "/mnt/SDCARD/Roms/"; then g=1; else g=0; fi
    if [ $g = 1 ]; then
        rompath=$(echo "$cmd" | awk '{ st = index($0,"\" \""); print substr($0,st+3,length($0)-st-3)}')
        if echo "$rompath" | grep -q ":"; then
            launch_script=$(echo "$rompath" | awk '{split($0,a,":"); print a[1]}')
            rompath=$(echo "$rompath" | awk '{split($0,a,":"); print a[2]}')
        fi
        romext=$(echo "$(basename "$rompath")" | awk -F. '{print tolower($NF)}')
        romcfgpath="$(dirname "$rompath")/.game_config/$(basename "$rompath" ".$romext").cfg"
    fi
    [ -z "$launch_script" ] && launch_script=$(echo "$cmd" | awk -F'"' '{print $2}')
    if echo "$rompath" | grep -q "\$"; then d=1; else d=0; fi
    echo "g=$g|rom=$rompath|ls=$launch_script|ext=$romext|cfg=$romcfgpath"
}
new_parse() {
    cmd=$1; rompath=""; launch_script=""; romext=""; romcfgpath=""
    cmd_single_line=1
    case "$cmd" in *"
"*) cmd_single_line=0 ;; esac
    case "$cmd" in *retroarch/cores* | */??/??/Roms/* | */mnt/SDCARD/Roms/*) g=1 ;; *) g=0 ;; esac
    if [ $g = 1 ]; then
        _after=${cmd#*\"\ \"}
        if [ $cmd_single_line -eq 1 ] && [ "$_after" != "$cmd" ]; then rompath=${_after%?}
        else rompath=$(echo "$cmd" | awk '{ st = index($0,"\" \""); print substr($0,st+3,length($0)-st-3)}'); fi
        case "$rompath" in *:*) launch_script=${rompath%%:*}; _after=${rompath#*:}; rompath=${_after%%:*} ;; esac
        _base=${rompath##*/}; romext=${_base##*.}
        case "$romext" in *[A-Z]*) romext=$(echo "$romext" | tr 'A-Z' 'a-z') ;; esac
        case "$rompath" in */*) _dir=${rompath%/*}; [ -z "$_dir" ] && _dir=/ ;; *) _dir=. ;; esac
        _base=${rompath##*/}; _name=${_base%".$romext"}; [ -z "$_name" ] && _name=$_base
        romcfgpath="$_dir/.game_config/$_name.cfg"
    fi
    if [ -z "$launch_script" ]; then
        if [ $cmd_single_line -eq 0 ]; then launch_script=$(echo "$cmd" | awk -F'"' '{print $2}')
        else case "$cmd" in *\"*) _after=${cmd#*\"}; launch_script=${_after%%\"*} ;; *) launch_script="" ;; esac; fi
    fi
    echo "g=$g|rom=$rompath|ls=$launch_script|ext=$romext|cfg=$romcfgpath"
}
fail=0; n=0
while IFS= read -r c; do
  n=$((n+1)); a=$(old_parse "$c"); b=$(new_parse "$c")
  [ "$a" = "$b" ] || { fail=$((fail+1)); echo "DIFF: $c"; echo "  old: $a"; echo "  new: $b"; }
done <<'CASES'
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/GB/launch.sh" "/mnt/SDCARD/Emu/GB/../../Roms/GB/Pokemon Red (USA).gb"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/GBA/launch.sh" "/mnt/SDCARD/Roms/GBA/Metroid Fusion.GBA"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/RetroArch/retroarch" -v -L .retroarch/cores/gambatte_libretro.so "/mnt/SDCARD/Roms/GB/Tetris.gb"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/PORTS/launch.sh" "/mnt/SDCARD/Roms/PORTS/Doom.port"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/SEARCH/launch.sh" "/mnt/SDCARD/Emu/NES/launch.sh:/mnt/SDCARD/Roms/NES/Zelda.nes"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/GB/launch.sh" "/mnt/SDCARD/Roms/GB/No Extension"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/SNES/launch.sh" "/mnt/SDCARD/Roms/SNES/Game.v1.2 (Rev A).sfc"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/GB/launch.sh" "/mnt/SDCARD/Roms/GB/Price $5 Game.gb"
cd /mnt/SDCARD/App/Terminal; ./launch.sh
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/App/Tweaks/launch.sh"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/GB/launch.sh" "/mnt/SDCARD/Roms/GB/.hidden"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/MD/launch.sh" "/mnt/SDCARD/Roms/MD/Sonic.MD" 
"/mnt/SDCARD/Emu/GB/launch.sh" "/mnt/SDCARD/Roms/GB/game.miyoocmd"
LD_PRELOAD=/mnt/SDCARD/miyoo/app/../lib/libpadsp.so "/mnt/SDCARD/Emu/ab/cd/Roms/x/launch.sh" "/tmp/x.gb"
CASES
echo "casi: $n, differenze: $fail"
