#include <limits.h>
#include "utils/file.h"
#include "utils/log.h"
#include "../Onion-onionplus-compact/src/playActivity/cacheDB.h"
#include <dirent.h>
static long rss_kb(void){ FILE*f=fopen("/proc/self/status","r"); char l[256]; long v=0; while(fgets(l,sizeof l,f)) if(!strncmp(l,"VmRSS:",6)) sscanf(l+6,"%ld",&v); fclose(f); return v; }
static int count_fds(void){ int n=0; DIR *d=opendir("/proc/self/fd"); struct dirent *e; while((e=readdir(d))) n++; closedir(d); return n; }
int main(void){
  system("rm -rf /mnt/SDCARD/Roms/GB && mkdir -p /mnt/SDCARD/Roms/GB");
  sqlite3 *db; sqlite3_open("/mnt/SDCARD/Roms/GB/GB_cache6.db",&db);
  sqlite3_exec(db,"CREATE TABLE GB_roms(id INTEGER PRIMARY KEY, disp TEXT, path TEXT, imgpath TEXT, pinyin TEXT);",0,0,0);
  sqlite3_exec(db,"BEGIN",0,0,0);
  char sql[512];
  for(int i=0;i<5000;i++){ snprintf(sql,sizeof sql,"INSERT INTO GB_roms(disp,path,imgpath,pinyin) VALUES('Game %d','/mnt/SDCARD/Roms/GB/game%d.gb','/mnt/SDCARD/Roms/GB/Imgs/game%d.png','Game %d');",i,i,i,i); sqlite3_exec(db,sql,0,0,0);}
  sqlite3_exec(db,"COMMIT",0,0,0); sqlite3_close(db);
  int before=count_fds(); long rss0=rss_kb();
  int found=0;
  for(int i=0;i<50;i++){ CacheDBItem *it=cache_db_find("/mnt/SDCARD/Roms/GB/game4990.gb"); if(it){found++; free(it);} }
  CacheDBItem *miss = cache_db_find("/mnt/SDCARD/Roms/GB/missing.gb"); free(miss);
  printf("found=%d leaked_fds=%d rss_growth=%ld KB\n",found,count_fds()-before,rss_kb()-rss0);
  return 0;
}
