#include "../Onion-onionplus-compact/src/playActivity/playActivityDB.h"
#include <time.h>
static int fails=0;
#define CHECK(c) do{ if(!(c)){printf("FAIL %d %s\n",__LINE__,#c);fails++;} }while(0)
static double now_ms(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1e3+t.tv_nsec/1e6; }
static int q_int(const char *sql){ int v=-1; sqlite3_stmt *st=play_activity_db_prepare((char*)sql); if(st&&sqlite3_step(st)==SQLITE_ROW) v=sqlite3_column_int(st,0); sqlite3_finalize(st); return v;}
int main(void){
  system("rm -rf /mnt/SDCARD/Saves; mkdir -p /mnt/SDCARD/Saves/CurrentProfile/play_activity");
  play_activity_db_open();
  sqlite3_exec(play_activity_db,"BEGIN",0,0,0);
  for(int i=0;i<200;i++){ char *q=sqlite3_mprintf("INSERT INTO rom(type,name,file_path) VALUES('x','g%d','GB/g%d.gb');",i,i); sqlite3_exec(play_activity_db,q,0,0,0); sqlite3_free(q);}
  for(int i=0;i<60000;i++){ char *q=sqlite3_mprintf("INSERT INTO play_activity(rom_id,play_time,created_at) VALUES(%d,%d,%d);",1+i%200, (i%500==0)?-5:100+i, 1000+i); sqlite3_exec(play_activity_db,q,0,0,0); sqlite3_free(q);}
  sqlite3_exec(play_activity_db,"INSERT INTO play_activity(rom_id,created_at) VALUES(7,strftime('%s','now')-30);",0,0,0);
  sqlite3_exec(play_activity_db,"COMMIT",0,0,0);
  /* query plan */
  sqlite3_stmt *st=play_activity_db_prepare("EXPLAIN QUERY PLAN UPDATE play_activity SET play_time=1 WHERE play_time IS NULL;");
  char plan[256]=""; if(st&&sqlite3_step(st)==SQLITE_ROW) snprintf(plan,sizeof plan,"%s",sqlite3_column_text(st,3)); sqlite3_finalize(st);
  printf("plan: %s\n",plan); CHECK(strstr(plan,"play_time_index")!=NULL);
  play_activity_db_close();
  double t0=now_ms(); play_activity_stop_all(); double t1=now_ms();
  printf("stop_all: %.2f ms\n",t1-t0);
  play_activity_db_open();
  CHECK(q_int("SELECT COUNT(*) FROM play_activity WHERE play_time IS NULL")==0);
  CHECK(q_int("SELECT COUNT(*) FROM play_activity WHERE play_time < 0")==0);
  int pt=q_int("SELECT play_time FROM play_activity WHERE rom_id=7 ORDER BY rowid DESC LIMIT 1"); printf("closed session: %d s\n",pt); CHECK(pt>=29 && pt<=32);
  CHECK(q_int("SELECT COUNT(*) FROM play_activity")==60000+1-120);
  play_activity_db_close();
  printf(fails?"FAILED %d\n":"ALL OK\n",fails); return fails;
}
