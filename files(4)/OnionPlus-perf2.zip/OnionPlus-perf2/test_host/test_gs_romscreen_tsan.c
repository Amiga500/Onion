#define _GNU_SOURCE
#include <SDL/SDL.h>
#include "../Onion-onionplus-compact/src/gameSwitcher/gs_history.h"
#include <stdatomic.h>

/* ---- stubs ---- */
static atomic_int live_surfaces = 0;
SDL_Surface *IMG_Load(const char *p){ (void)p; usleep(2000); SDL_Surface *s=calloc(1,sizeof *s); s->w=640; s->h=480; atomic_fetch_add(&live_surfaces,1); return s; }
void SDL_FreeSurface(SDL_Surface *s){ if(s){ atomic_fetch_sub(&live_surfaces,1); memset(s,0xAB,sizeof *s); free(s);} }
SDL_Surface *zoomSurface(SDL_Surface *s,double a,double b,int c){ (void)a;(void)b;(void)c; SDL_Surface *z=calloc(1,sizeof *z); z->w=s->w; z->h=s->h; atomic_fetch_add(&live_surfaces,1); return z; }

static int cur = 0;
int main(void){
  system("mkdir -p /mnt/SDCARD/Saves/CurrentProfile/romScreens");
  srand(1);
  romscreen_prefetch_play_time = true;
  system("mkdir -p /mnt/SDCARD/Saves/CurrentProfile/play_activity");
  for (int round=0; round<30; round++){
    game_list_len = 60;
    for(int i=0;i<game_list_len;i++){
      Game_s *g=&game_list[i]; memset(g,0,sizeof *g);
      setEntryDefaultValues(g,i);
      snprintf(g->recentItem.rompath,sizeof g->recentItem.rompath,"/tmp/gsrom_%d.gb",i);
      snprintf(g->recentItem.imgpath,sizeof g->recentItem.imgpath,"/tmp/gsimg.png");
    }
    cur=0;
    loadRomScreens();
    for(int step=0; step<400; step++){
      int r=rand()%10;
      if(r<7){ cur += (rand()%3)-1; }
      else if(r<9){ cur += (rand()%9)-4; }
      if(cur<0) cur=0;
      if(cur>=game_list_len) cur=game_list_len-1;
      Game_s *g=&game_list[cur];
      processItem(g);
      volatile size_t tl = strlen(g->totalTime); (void)tl;
      SDL_Surface *s=loadRomScreen(cur);
      if(s && s->w!=640){ printf("CORRUPT surface\n"); return 1; }
      romscreen_prefetch(cur);
      if(rand()%40==0 && game_list_len>3){
        romscreen_lockForUpdate();
        /* same shifting as removeCurrentItem() */
        Game_s *gg=&game_list[cur];
        if(gg->romScreen){ SDL_FreeSurface(gg->romScreen); gg->romScreen=NULL; }
        for(int i=cur;i<game_list_len-1;i++){ game_list[i]=game_list[i+1]; game_list[i].index-=1; }
        game_list_len--;
        romscreen_unlock();
        if(cur>0) cur--;
      }
      if(step%50==0) usleep(3000);
    }
    freeRomScreens();
    if(atomic_load(&live_surfaces)!=0){ printf("LEAK %d surfaces after round %d\n", atomic_load(&live_surfaces), round); return 1; }
  }
  printf("GS STRESS OK\n");
  return 0;
}
