#define _GNU_SOURCE
#include <SDL/SDL.h>
#include TREE_HISTORY
SDL_Surface *IMG_Load(const char *p){(void)p;return NULL;}
void SDL_FreeSurface(SDL_Surface *s){(void)s;}
SDL_Surface *zoomSurface(SDL_Surface *s,double a,double b,int c){(void)a;(void)b;(void)c;return s;}
int main(int argc,char**argv){
  const char *rp=getMiyooRecentFilePath();
  FILE *f=fopen(rp,"w");
  char longname[1500]; memset(longname,'L',1200); longname[1200]=0;
  const char *roms[]={"A","B","A","C","B","MISSING","D","A",longname,"E","C","F"};
  int n=sizeof roms/sizeof roms[0];
  for(int i=0;i<n;i++){
    if(i==5){ fprintf(f,"not json at all\n"); }
    fprintf(f,"{\"label\":\"%.20s\",\"rompath\":\"/tmp/rhroms/%s.gb\",\"imgpath\":\"\",\"launch\":\"/tmp/rhroms/launch.sh\",\"type\":5}\n",roms[i],roms[i]);
  }
  fclose(f);
  readHistory();
  printf("len=%d\n",game_list_len);
  for(int i=0;i<game_list_len;i++){
    char *l=file_read_lineN(rp,game_list[i].recentItem.lineNo);
    const char *base=strrchr(game_list[i].recentItem.rompath,'/')+1;
    int ok = l && strstr(l,game_list[i].recentItem.rompath)!=NULL;
    printf("%.12s line=%d %s\n",base,game_list[i].recentItem.lineNo, ok?"OK":"MISMATCH");
    free(l);
  }
  f=fopen(rp,"r"); int lines=0; char *ln=NULL; size_t cap=0; while(getline(&ln,&cap,f)!=-1) lines++; fclose(f); free(ln);
  printf("file lines after=%d\n",lines);
  return 0;
}
